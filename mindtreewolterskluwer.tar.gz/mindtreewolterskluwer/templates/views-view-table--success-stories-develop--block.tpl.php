<div id="StoryBlocks">
	<?php foreach ($rows as $row_count => $row): ?>
		<div class="each-block-wrapper ">
		    <div class="custom-container clearfix">
		        <div class="img-block" style="background:url('/sites/default/files/<?php print trim($row['field_success_stories_image']); ?>') no-repeat center center / cover" >
		            <div class="block-content hidden-xs hidden-sm">
		                <div class="block-content-title rfly-obj">
		                    <?php print $row['field_success_stories_image_text']; ?>
		                </div>
		                <div class="block-icon">
		                    <div class="industry-type-icon"><img src="<?php print $row['field_success_stories_icon']; ?>">
		                    </div>
		                    <div class="industry-type-name">
		                    	<?php print $row['field_success_stories_icon_text']; ?>
		               			 </div>
		            		</div>
		    				</div>
		            <div class="in-mobile-banner-info hidden-lg hidden-md">
		                <div class="industry-type-icon"><img src="<?php print $row['field_success_stories_icon']; ?>">
		                </div>
		                <div class="industry-type-name"><?php print $row['field_success_stories_icon_text']; ?></div>
		                <!--   <h2><?php //  print $row['title']; ?></h2> -->
		            </div>
		        	</div>
						<div class="content-block">
	            <div class="content-block-wrapper">
	                <h2 class="hidden-xs hidden-sm"><?php print $row['title']; ?></h2>
	                <div class="break-line hidden-xs hidden-sm"></div>
	                <div class="padded-box">
	                    <?php print $row['body']; ?>
	                </div>
	            </div>
	        	</div>
        </div>
		</div>
	<?php endforeach; ?>
</div>