<h2 class="client-participants-title">CLIENT PARTICIPANTS:</h2>
<div class="team-image-tiles">
 	<?php foreach ($rows as $row_count => $row): ?>
 		<div class="teams-each-block <?php print strtolower(str_replace(" ", "", $row['title'])); ?>">
	 		<a href="<?php print $row['path']; ?>">
		 		<div class="team-thumbnail-image"> <?php print $row['field_image']; ?></div>
				<div class="team-thumbnail-description">
					<div class="small-pink-cercle"></div>
					<h2><?php print $row['title']; ?></h2>
					<h3><?php print $row['field_team_designation']; ?></h3>
        		</div>
			</a>
		</div>
	<?php endforeach; ?>
</div>