<?php
  global $user;
  if ($user->uid == 0 && arg(0) != 'user' && arg(1) != 'login') {
    drupal_goto('userlogin');
  } else {
?>
  <!-- Header Section -->
  <header id="Header">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
          <?php print render($page['top_logo_post_login']); ?>
        </div>
        <div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
          <div class="container-fluid">
            <div class="row">
              <div class="col-xs-6 col-sm-12 col-md-12 col-lg-12 visible-xs">
                <div class="mobile-menu">
                  <?php print render($page['mobile_menu']); ?>
                </div>
              </div>
              <div class="col-xs-6 col-sm-12 col-md-12 col-lg-12">
                <div class="log-out">
                  <?php print render($page['top_logout']); ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
       <div class="row hidden-xs">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <div class="main-menu">
            <?php print render($page['main_menu']); ?>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- Main Container Section-->
<section id="MainContainer">
   <div class="container">
    <div class="reg-content">
    <?php if($is_admin): ?><?php print $messages; ?><?php endif; ?>
    <div id="CategoryTitle">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <h3 class="category-leadership">
            <?php print render($page_team_category); ?>
            </h3>
          </div>
        </div>
   </div>
    <?php print render($title_suffix); ?>
    <?php if ($tabs): ?>
      <div class="tabs"><?php print render($tabs); ?></div>
    <?php endif; ?>
    <?php print render($page['help']); ?>
    <?php if ($action_links): ?>
      <ul class="action-links">
        <?php print render($action_links); ?>
      </ul>
    <?php endif; ?>
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
      <div id="leadership-profile-enclosing-wrapper" class="clearfix" data-sticky_parent>
        <div id="floating-image" class="col-xs-12 col-sm-4 col-md-3 col-lg-3 null-padding" data-sticky_column>
          <div class="floating-image">
            <?php print render($page_image); ?>
          </div>
        </div>
        <div class="col-xs-12 col-sm-8 col-md-9 col-lg-9 reg-content about-leaders">
        <h1><?php print $title; ?></h1>
        <h2 class="designation-leadership"><?php print render($page_team_designation); ?></h2>
        <div class="team-info">
          <?php print render($page_team_info); ?>
        </div>
            <?php print render($page['content']); ?>
        </div>
      </div>
    </div>
    </div>
    <div class="row">
      <div id="leadership-slider-enclosing-wrapper">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <?php print render($page['team_slider']); ?>
        </div>
      </div>
    </div>
  </div>
</div>
  </section> 
  <!-- Footer Section-->
  <footer id="Footer">
    <div class="container">
      <div id="FooterCopyright">
        <div class="row">
          <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <?php print render($page['footer_copy_left']); ?>
          </div>
          <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
            <?php print render($page['footer_social_links_right']); ?>
          </div>
        </div>
      </div>
    </div>
  </footer>
<?php } ?>