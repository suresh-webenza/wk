<?php
  global $user;
  if ($user->uid) {
    drupal_goto('<front>');
  } 
?>
<!-- Main Container Section-->
<?php if($is_admin): ?><?php print $messages; ?><?php endif; ?>
<?php print render($title_suffix); ?>
<?php if ($tabs): ?>
  <div class="tabs"><?php print render($tabs); ?></div>
<?php endif; ?>
<?php print render($page['help']); ?>
<?php if ($action_links): ?>
  <ul class="action-links">
    <?php print render($action_links); ?>
  </ul>
<?php endif; ?>
<div class="outer-wrapper">
  <div class="bottom-logo">
    <img src="/sites/default/files/flair.png" class="flair">
    <img class="badge-icon" src="/sites/default/files/anzac-logo.svg" alt="Logo">
  </div>
  <div class="logo-login-wrapper">
    <div class="main-logo">
      <img src="/sites/default/files/login-page-logo.svg" alt="Logo">
    </div>
    <div id="LoginBox">
      <?php print render($page['content']); ?>
    </div>
  </div>
</div>
<!-- Footer Section-->
<footer id="Footer">
  <div class="container">
    <div id="FooterCopyright">
      <div class="row">
        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
          <?php print render($page['footer_copy_left']); ?>
        </div>
        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
          <?php print render($page['footer_social_links_right']); ?>
        </div>
      </div>
    </div>
  </div>
</footer>