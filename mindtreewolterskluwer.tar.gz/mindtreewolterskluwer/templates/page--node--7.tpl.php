<?php     
  header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
  header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
  header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
  header("Cache-Control: post-check=0, pre-check=0", false);
  header("Pragma: no-cache");
?>
<!-- Main Container Section-->
<section id="MainContainer">
  <div class="inner_main_middle1">
            <div class="welcom_msg1">
                <a href="userlogin">Login</a>
            </div>  
        </div>
  <?php if($is_admin): ?><?php print $messages; ?><?php endif; ?>
  <?php print render($title_suffix); ?>
  <?php if ($tabs): ?>
    <div class="tabs"><?php print render($tabs); ?></div>
  <?php endif; ?>
  <?php print render($page['help']); ?>
  <?php if ($action_links): ?>
    <ul class="action-links">
      <?php print render($action_links); ?>
    </ul>
  <?php endif; ?>
  <div class="reg-content">
    <?php print render($page['content']); ?>
  </div>
</section>