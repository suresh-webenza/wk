<ul class="leadership-carousel">
   <?php foreach ($rows as $row_count => $row): ?>
        <li class="team-top-box">
        <a href="<?php print $row['path']; ?>">
            <div class="team-detail-wrapper <?php print strtolower(str_replace(" ", "", $row['title'])); ?>">
                <div class="team-photo">
                    <?php print $row['field_image']; ?>
                </div>
                <div class="team-desc-carousel">
                    <h2 class="team-name"><?php print $row['title']; ?></h2>
                    <h3 class="team-designation"><?php print $row['field_team_designation']; ?></h3>
                </div>
            </div>
        </a>
        </li>
   <?php endforeach; ?>
</ul>