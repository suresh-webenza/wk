<?php
  global $user;
  if ($user->uid == 0 && arg(0) != 'user' && arg(1) != 'login') {
    drupal_goto('userlogin');
  } else {
?>
  <!-- Header Section -->
  <header id="Header">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-6 col-md-5 col-lg-5">
          <?php print render($page['top_logo_post_login']); ?>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-7 col-lg-7">
          <div class="container-fluid">
            <div class="row">
              <div class="col-xs-6 col-sm-12 col-md-12 col-lg-12 visible-xs">
                <div class="mobile-menu">
                  <?php print render($page['mobile_menu']); ?>
                </div>
              </div>
              <div class="col-xs-6 col-sm-12 col-md-12 col-lg-12">
                <div class="log-out">
                  <?php print render($page['top_logout']); ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
       <div class="row hidden-xs">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <div class="main-menu">
            <?php print render($page['main_menu']); ?>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- Main Container Section-->
  <section id="MainContainer">
    <?php if($is_admin): ?><?php print $messages; ?><?php endif; ?>
    <?php print render($title_suffix); ?>
    <?php if ($tabs): ?>
      <div class="tabs"><?php print render($tabs); ?></div>
    <?php endif; ?>
    <?php print render($page['help']); ?>
    <?php if ($action_links): ?>
      <ul class="action-links">
        <?php print render($action_links); ?>
      </ul>
    <?php endif; ?>
    <div class="reg-content">
      <?php print render($page['content']); ?>
    </div>
  </section> 
  <!-- Footer Section-->
  <footer id="Footer">
    <div class="container">
      <div id="FooterCopyright">
        <div class="row">
          <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <?php print render($page['footer_copy_left']); ?>
          </div>
          <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
            <?php print render($page['footer_social_links_right']); ?>
          </div>
        </div>
      </div>
    </div>
  </footer>
<?php } ?>