/* =====================================================
   Mindtree CALTEX Microsite Plugins Activate
======================================================== */
(function($jq) {
    $jq(document).ready(function() {
        $jq(".video-pop").fancybox({
            type: 'iframe',
            autoSize: false,
            'width': 600,
            padding: 0
        });
        //Mobile Menu
        $jq("#dl-menu").dlmenu();
        $jq("#MakeDigital .each-section h2").textfill({
            maxFontPixels: 24,
            innerTag: 'span',
            changeLineHeight: true
        });
        $jq(window).load(function() {
            if (ieVersion() > 0) {
                $jq(".digital-info svg").attr("class", "svg-fluid");
                $jq(".digital-info").height(621);
                $jq(".digital-info").addClass("svg_outer-fluid");
            }
        });
        // SVG IE
        function ieVersion() {
            var ua = window.navigator.userAgent;
            if (ua.indexOf("Trident/7.0") > 0)
                return 11;
            else if (ua.indexOf("Trident/6.0") > 0)
                return 10;
            else if (ua.indexOf("Trident/5.0") > 0)
                return 9;
            else
                return 0; // not IE9, 10 or 11
        }
        // ScrollReveal
        window.sr = ScrollReveal({ reset: true });
        sr.reveal('.tfly-obj', { origin: 'top', distance: '50px', duration: 1000 });
        sr.reveal('.rfly-obj', { origin: 'right', distance: '100px', duration: 2000 });
        sr.reveal('.lfly-obj', { origin: 'left', distance: '100px', duration: 2000 });
        // odd nad even
        $jq('.each-block-wrapper:odd').addClass('odd');
        $jq('.each-block-wrapper:even').addClass('even');
        //JPlayer : PODCAST SERIES: CLIENT STORIES
        new jPlayerPlaylist({
            jPlayer: "#jquery_jplayer_2",
            cssSelectorAncestor: "#jp_container_2"
        }, [{
                title: "Fortune 500 insurer strengthens broker productivity",
                mp3: "sites/all/themes/mindtreecaltexdpthemevone/audio-files/AIG-broker-portal.mp3",
            },
            {
                title: "Global insurance company improves employee collaboration",
                mp3: "sites/all/themes/mindtreecaltexdpthemevone/audio-files/AIG-intranet.mp3",
            },
            {
                title: "Sports apparel manufacturer embarks on enterprise-wide portal transformation",
                mp3: "sites/all/themes/mindtreecaltexdpthemevone/audio-files/Adidas.mp3",
            },
            {
                title: "Automaker provides a community platform for owners and dealers",
                mp3: "sites/all/themes/mindtreecaltexdpthemevone/audio-files/Toyota.mp3",
            }
        ], {
            swfPath: "js",
            supplied: "mp3",
            wmode: "window",
            smoothPlayBar: true,
            keyEnabled: true
        });
        // Team Page bx-slider
        $jq('.leadership-carousel').bxSlider({
            minSlides: 1,
            maxSlides: Math.floor($jq(".leadership-carousel").outerWidth() / 260),
            slideWidth: 260,
            slideMargin: 0,
            auto: $jq(window).width() > 767 ? false : true,
            moveSlides: 1,
            hideControlOnEnd: $jq(window).width() < 767 ? false : true,
            infiniteLoop: $jq(window).width() < 767 ? true : false,
            pager: false
        });
        // Team Page sticky image
        if($jq(window).width() > 767) {
          $jq("#floating-image").stick_in_parent();
        }
    });
})(jQuery);