<?php
function mindtreecaltexdpthemevone_preprocess_page(&$vars) {
  if (arg(0)!='admin') {
    $scripts = drupal_add_js('caltex.mindtree.com/sites/all/themes/mindtreecaltexdpthemevone/scripts/jquery-1.11.3.min.js');
    unset($scripts['core']['/misc/jquery.js']);
    $variables['scripts'] = drupal_get_js('header', $scripts);
  }
  // This code looks for any page--custom_content_type.tpl.php page
		if (isset($vars['node']->type)) {
			$vars['theme_hook_suggestions'][] = 'page__' . $vars['node']->type;
		}
	// This code grabs the Designation from Leadership profile image
			if(isset($vars['node']) && $vars['node']->type == 'leadership') {
				if ($node = menu_get_object()) {
					$vars['page_image'] = field_view_field('node', $node, 'field_image', 'full');
		}
	}
	// This code grabs the Designation from Leadership type
			if(isset($vars['node']) && $vars['node']->type == 'leadership') {
				if ($node = menu_get_object()) {
					$vars['page_team_info'] = field_view_field('node', $node, 'field_team_info', 'full');
		}
	}
	// This code grabs the Right Block from Leadership type
			if(isset($vars['node']) && $vars['node']->type == 'leadership') {
				if ($node = menu_get_object()) {
					$vars['page_linkedin_profile'] = field_view_field('node', $node, 'field_linkedin_profile', 'full');
		}
	}
	// This code grabs the Right Block from Leadership type
			if(isset($vars['node']) && $vars['node']->type == 'leadership') {
				if ($node = menu_get_object()) {
					$vars['page_team_category'] = field_view_field('node', $node, 'field_team_category', 'full');
		}
	}
		if(isset($vars['node']) && $vars['node']->type == 'leadership') {
			if ($node = menu_get_object()) {
				$vars['page_team_designation'] = field_view_field('node', $node, 'field_team_designation', 'full');
		}
	}
}